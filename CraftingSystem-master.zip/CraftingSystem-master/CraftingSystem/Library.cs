﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace CraftingSystemMonday
{
    public class Library
    {
        #region Display Methods
        public static void Print(string message)
        {
            Console.WriteLine(message); //this is for console applications
            //TODO: add functionality for other platforms
        }
        // Read a line from console and return an empty string if null
        public static string GetInput()
        {
            var input = Console.ReadLine();
            return input ?? string.Empty;
        }
        #endregion

        #region Conversion Methods
        // Try to parse an integer; return -1 for invalid input
        public static int ConvertStringToInteger(string value)
        {
            int result;
            int.TryParse(value, out result);
            return result;
        }

        public static double ConvertStringToDouble(string value)
        {
            double result;
            double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out result);
            return result;
        }

        public static float ConvertStringToFloat(string value)
        {
            float result;
            float.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out result);
            return result;
        }
        #endregion
        public static bool IsNumber(string value)
        {
            int number; return int.TryParse(value, out number);
        }

        string userInput = Library.GetInput();

        public bool SearchText(string text, string searchTerm)
        {
            if (text.Contains(searchTerm))
            {
                return true;
            }
            return false;
        }

        public static void AddToCollectionByName(string name, List<Item> collection, Item itemToAdd)
        {
            if (itemToAdd.Name == name)
            {
                collection.Add(itemToAdd);
            }

        }
        public static int SearchInventoryByName(string searchTerm, List<Item> inventory)
        {
            return inventory.FindIndex(item => item.Name.Contains(searchTerm));
        }
        public static void RemoveFromInventoryByName(string searchTerm, List<Item> inventory)
        {
            int index = SearchInventoryByName(searchTerm, inventory);

            if (index != -1)
            {
                inventory.RemoveAt(index);
            }
        }
    }
}


