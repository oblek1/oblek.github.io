﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using static CraftingSystemMonday.Library;
namespace CraftingSystemMonday
{
    public class Person
    {
        private string personName;
        private double Currency = 10.50;
        public Person() 
        { 
            Inventory.Add(new Item() 
            {
                Name = "Water",
                Description = "Clean, lovely, water", 
                Amount = 2,
                Value = .0015, 
                AmountType = "cup(s)"
            }
            );
            Inventory.Add(new Item()
            {
                Name = "Chamomile",
                Description = "Matricaria recutita, dried",
                Amount = 1,
                Value = 0.0875,
                AmountType = "tsp(s)"
            }
           );
            Inventory.Add(new Item()
            {
                Name = "Ashwagandha",
                Description = "Withania somnifera, extract",
                Amount = 1,
                Value = 0.7475,
                AmountType = "tsp(s)"
            }
            );
            Inventory.Add(new Item()
            {
                Name = "Lavender",
                Description = "Lavandula angustifolia, dried",
                Amount = 1,
                Value = 032.5,
                AmountType = "tsp(s)"
            }
            );
            Inventory.Add(new Item()
            {
                Name = "Lemon Balm",
                Description = "Melissa officinalis, dried",
                Amount = 1,
                Value = 0.87375,
                AmountType = "tsp(s)"
            }
            );

        }
        public string Name
        {
            get => personName;
            set => personName = value;

        }
        //list inventory - item
        public List<Item> Inventory = new List<Item>();

        public void Craft()
        {
            throw new System.NotImplementedException();
        }

       // public string Information()
      //  {
       //     return $"{personName} {Currency.ToString("c")}";
       // }

        // expression bodied method
        public string Information() => $"{personName} has {Currency.ToString("C")}";
        public string SetName()
        {
            Print("Do you want to customize your name? Type y for yes, n for no:");
            string input = Console.ReadLine();

            if (input.ToLower() == "y")

            {
                Console.Clear();
                //get info from the player what the name will be
                Print("What would you like your name to be?");

                //set personName = to the string player entered
                personName = GetInput();
                Console.Clear();
                return $"Your name has been updated to {personName}";
            }
            else
            {
                personName = "Player 1";
                return $"Your name is set to {personName}";
            }
        }
       


    }
}