﻿using CraftingSystem;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CraftingSystemMonday.Library;
using static CraftingSystemMonday.Person;
namespace CraftingSystemMonday
{


    public class Engine
    {
        //player
        Person Player = new Person();
        Person Vendor = new Person();

        public List<Recipe> Recipes = new List<Recipe>();


        //name of my system
        private string name = "Awesome Potion Crafting System";

        public void Setup()
        {
            Recipes.Add(
                new Recipe(
                    "Chamomile Tea",
                    "recipe description",
                    new List<Item>()
                    {
                        new Item(){Name ="Water", Amount = 1, Value = .0015, Description = "water", AmountType = "cup(s)"  },
                        new Item(){Name ="Chamomile", Amount = 1, Value = .0015, Description = "Matricaria recutita, dried", AmountType = "tsp(s)"  },

                    }
                )
                );
            Recipes.Add(new Recipe() { Name = "recipe 2" });
            Print(name);
            Print(Player.SetName());
            Run();

        }
        private void Run()
        {
            Print(Player.Information());
            Print(showMenu());
            int number = ConvertStringToInteger(GetInput());
            if (number > 0)
            {
                //show the thing player chose
                switch (number)
                {
                    case 1:
                        break;
                    case 2:
                        ShowAllRecipes();
                        break;
                    case 3:
                        break;
                    case 4:
                        break;
                    case 5:
                        return;
                }
            }
        }
        private string showMenu()
        {
            string output = "Choose an option:";
            output += "\n1. Show inventory";
            output += "\n2. Show recipes";
            output += "\n3. See recipe details";
            output += "\n4. Craft";
            output += "\n5. View Credits";

            return output;
        }
        public void ShowAllRecipes()
        {
            Print("Available Recipes:");
            int number = 1;
            foreach (Recipe recipe in Recipes)
            {
                Print($"   {number}. {recipe.Information()}");

                number++;
            }

        }

        public void RecipeMenu()
        {
            ShowAllRecipes();
            Print("Enter the number of the recipe you would like to view:");
            string choice = GetInput();
            int num = ConvertStringToInteger(choice);
            if (num >= 1 && num < Recipes.Count)
            {
                //great - we got a good number
                Print(Recipes[num - 1].Information());
            }
            else
            {
                //print message saying enter right range as number
                //recursive RecipeMenu()
            }
        }

    }


}