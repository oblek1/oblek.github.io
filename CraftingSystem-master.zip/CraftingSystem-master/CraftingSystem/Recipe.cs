﻿using CraftingSystemMonday;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CraftingSystem;
public class Recipe
{
    public string Name;
    public double Amount;
    public string AmountType;
    public double Value;
    public string Description;
    public double YieldAmount;
    public List<Item> Ingredients = new List<Item>();

    public string GetIngredientList()
    {
        string output = "";
        foreach (Item item in Ingredients)
        {
            output += item.ToString();
        }
        return output;
    }
    public Recipe(string name, string description, List<Item> items)
    {
        Name = name;
        Description = description;
        Ingredients = items;
    }
    public Recipe() 
    {
 

    }
    public string Information()
    {
        return $"    *{Name} ({Description})";
    }
}