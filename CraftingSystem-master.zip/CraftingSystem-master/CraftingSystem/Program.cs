﻿using static System.Console;

namespace CraftingSystemMonday
{
    internal class Program
    {
        static void Main()
        {
            Title = "Awesome Potion Crafting System";
            new Engine().Setup();

            //alternative option
            //Engine engine = new Engine();
            // engine.Setup();
        }
    }
}