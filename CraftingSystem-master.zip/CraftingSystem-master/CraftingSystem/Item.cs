﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CraftingSystemMonday
{
    public class Item
    {
        public string Name;
        public string Description;
        public double Value;
        public double Amount = 1;
        public string AmountType = "cup(s)";
        public Item() { }
        public Item(string name) 
        {
        Name = name;

        }

    }
}